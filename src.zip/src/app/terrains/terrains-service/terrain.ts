export interface Terrain {
  id: string;
  name: string;
  description: string;
  date: any;
  workflows: object;
}
